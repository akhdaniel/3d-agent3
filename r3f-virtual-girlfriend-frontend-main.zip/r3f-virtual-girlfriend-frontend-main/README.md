![Video Thumbnail](https://img.youtube.com/vi/EzzcEL_1o9o/maxresdefault.jpg)

[Video tutorial](https://youtu.be/EzzcEL_1o9o)

The backend is [here](https://github.com/wass08/r3f-virtual-girlfriend-backend).

Start the development server with
```
yarn
yarn dev
```
