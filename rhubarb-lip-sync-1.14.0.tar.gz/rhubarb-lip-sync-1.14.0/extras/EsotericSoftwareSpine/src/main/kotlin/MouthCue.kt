package com.rhubarb_lip_sync.rhubarb_for_spine

data class MouthCue(val time: Double, val mouthShape: MouthShape)
