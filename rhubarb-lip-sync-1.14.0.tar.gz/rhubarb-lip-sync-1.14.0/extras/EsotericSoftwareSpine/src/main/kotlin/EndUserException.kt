package com.rhubarb_lip_sync.rhubarb_for_spine

// An exception with a human-readable message that can be shown to the end user
class EndUserException(message: String): Exception(message)