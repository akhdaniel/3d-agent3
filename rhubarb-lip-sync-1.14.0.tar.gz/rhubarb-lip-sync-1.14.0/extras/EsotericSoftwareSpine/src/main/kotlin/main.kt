package com.rhubarb_lip_sync.rhubarb_for_spine

import javafx.application.Application

fun main(args: Array<String>) {
	Application.launch(MainApp::class.java, *args)
}
