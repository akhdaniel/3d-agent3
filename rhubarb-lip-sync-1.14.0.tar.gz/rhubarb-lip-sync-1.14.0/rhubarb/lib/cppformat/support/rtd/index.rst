If you are not redirected automatically, follow the
`link to the C++ Format documentation <http://cppformat.github.io/latest/>`_.
