/*

This library is header-only.
Due to limitations in CMake, I added this dummy code file.
For details, see http://cmake.3232098.n2.nabble.com/Cannot-set-FOLDER-property-to-an-interface-header-only-target-td7592375.html

*/